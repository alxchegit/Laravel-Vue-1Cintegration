define(['./app.js', 'jquery', 'lib/components/base/modal', 'underscore', 'lib/components/base/confirm'], function (App, $, Modal, _, Confirm) {
	return function () {
		const $body = $('body')
		const self = this;
		const system = self.system();
		const ai_widget_name = 'amoai_td_lfb';
		const ai_widget_code = 'amoai_td_lfb';
		const urlAPI = 'https://tdlfb.amoai.ru';
		const urlPanelAPI = 'https://amoai.ru/pm';
		const error_msg = 'Произошла ошибка на стороне сервера! Обратитесь в службу технической поддержки виджета.';
		self.templates = {};
		self.base_path = urlAPI + '/widget';
		self.hasSettingsTab = true;
		self.tabItemTemplate = 'tab_item';
		self.tabContentTemplate = 'tab_content';
		self.settingsTemplatesArray = [self.tabItemTemplate, self.tabContentTemplate, 'order_form'];
		self.logs = [];
		//Утилиты
		self.utils = {
		  getAccountId() {
		    return AMOCRM.constant('account').id
      },
			getWidgetId(postfix, hash) {
				hash = typeof hash !== 'undefined' ? hash : true;
				postfix = typeof postfix !== 'undefined' ? postfix : '';
				return (hash ? '#' : '') + self.params.widget_code + (postfix ? '_' + postfix : '');
			},
			openNotifications(text, type = 'success') {
				const params = {
					header: ai_widget_name,
					text: text
				};
				if (type === 'success') {
					AMOCRM.notifications.show_message(params);
					return true;
				}
				if (type === 'error') {
					AMOCRM.notifications.show_message_error(params);
					return true;
				}
				return false;
			},
			openAlert(text, type = 'success') {
				if (type === 'success') {
					return new Modal()._showSuccess(text, false, 3000);
				}
				if (type === 'error') {
					return new Modal()._showError(text, false);
				}
				return false;
			},
			openModal(data, class_name) {
				self.openedModal = new Modal({
					class_name: 'modal-list ' + class_name,
					init: function ($modalBody) {
						const $this = $(this);
						$modalBody
							.trigger('modal:loaded')
							.html(data)
							.trigger('modal:centrify')
							.append('<span class="modal-body__close"><span class="icon icon-modal-close"></span></span>');
					},
					destroy: function () {
						self.openedModal = false;
					}
				});
			},
			appendCss(file) {
				if ($(`link[href="${self.base_path}/css/${file}?v=${self.params.version}"]`).length) {
					return false;
				}
				$('head').append(`<link type="text/css" rel="stylesheet" href="${self.base_path}/css/${file}?v=${self.params.version}">`);
				return true;
			},
			loader(querySelector, show = false, refresh = false) {
				if (show === true) {
					if (refresh) {
						$(querySelector).html(
							'<div class="overlay-loader">' +
							'<span class="spinner-icon spinner-icon-abs-center"></span>' +
							'</div><br>'
						);
						return true;
					}
					$(querySelector).prepend(
						'<div class="overlay-loader">' +
						'<span class="spinner-icon spinner-icon-abs-center"></span>' +
						'</div><br>'
					);
					return true;
				}
				$(querySelector).find('.overlay-loader').remove();
				return true;
			},
			loadTemplates(templates, callback) {
				const templateName = templates.shift()
				if (templateName === undefined) {
					callback()
					return
				}
				if (self.templates[templateName] !== undefined) {
					self.utils.loadTemplates(templates, callback)
					return
				}
				// noinspection JSUnusedGlobalSymbols
				self.render({
					href: `/templates/${templateName}.twig`,
					base_path: self.base_path,
					load(template) {
						self.templates[templateName] = template
						self.utils.loadTemplates(templates, callback)
					}
				}, {});
			},
			initializeVue(parentBLockSelector, condition = true) {
				$(parentBLockSelector).append(`<div id="${self.params.widget_code}_vue_app"></div>`)
				if (condition) {
					self.utils.appendCss('app.css')
					App.default.render(self, `#${self.params.widget_code}_vue_app`, urlAPI)
				}
			},
		};

	// Методы виджета
		self.widget_methods = {
			// Кол-во активных пользователей
			activeUsers() {
				let users = 0;
				for (const manager in AMOCRM.constant('managers')) {
					if (AMOCRM.constant('managers')[manager].active === true) {
						users++;
					}
				}
				return users;
			},
			// Пользователи на аккаунте
			amoUsers() {
				return _.map(AMOCRM.constant('account').users, function(val, indx){
					return {
						id: indx,
						name: val
					}
				});
			},
			// Пользователи 1С
			cUsers() {
				return [
					{
						id: "8ceeed45-a0e7-11eb-823f-00155d331416",
						name: "Цымбалюк Андрей Сергеевич"
					},
					{
						id: "c56a8a4b-0a27-11e7-96dc-00155d00830d",
						name: "Зотов Александр"
					},
					{
						id: "86aecd1c-8dee-11e9-a0f4-b06ebfd1ffe9",
						name: "Наумов Дмитрий Павлович"
					},
					{
						id: "cf6b244f-9efa-11e9-a0f5-b06ebfd1ffe9",
						name: "Ибрагимова Лилия Винеровна"
					}
				]
			}
		}

		this.callbacks = {
			render() {
				self.utils.appendCss('style.css');
				return true
			},
			init() {
				return true
			},
			bind_actions() {
				// View "Settings" tab
				$body.off('change', self.utils.getWidgetId() + ' .view-integration-modal__tabs input[name="type_integration_modal"]');
				$body.on('change', self.utils.getWidgetId() + ' .view-integration-modal__tabs input[name="type_integration_modal"]', function () {
					let id = $(self.utils.getWidgetId() + ' .view-integration-modal__tabs input[name="type_integration_modal"]:checked').attr('id');
					if (id === 'setting') {
						$(self.utils.getWidgetId() + ' .view-integration-modal__keys').addClass('hidden');
						$(self.utils.getWidgetId() + ' .view-integration-modal__access').addClass('hidden');
						$(self.utils.getWidgetId() + ' .widget-settings__desc-space').addClass('hidden');
						$(self.utils.getWidgetId() + ' .view-integration-modal__setting').removeClass('hidden');
					} else {
						$(self.utils.getWidgetId() + ' .view-integration-modal__setting').addClass('hidden');
					}
				});
				// Open "OrderForm"
				$body.off('click', `#${ai_widget_code}_buy_widget_btn`);
				$body.on('click', `#${ai_widget_code}_buy_widget_btn`, function (e) {
					e.preventDefault();
					self.openOrderForm();
				});
				// Send "OrderForm"
				$body.off('click', `#${ai_widget_code}_buy_widget_send`);
				$body.on('click', `#${ai_widget_code}_buy_widget_send`, function (e) {
					e.preventDefault();
					self.sendOrderForm($(this));
				});
				return true;
			},
			settings() {
				const $modal = $('.widget-settings__modal.' + self.params.widget_code);
				const $save = $modal.find('button.js-widget-save');
				$modal.attr('id', self.utils.getWidgetId('', false)).addClass('amoai-settings');

				self.utils.loadTemplates(['modal_footer'], async function () {
					// Add footer
					const footerHtml = self.templates['modal_footer'].render({
						self: self
					});
					$modal.find('.widget-settings__wrap-desc-space').append(footerHtml);
				})

				if (self.get_install_status() !== 'installed') {
					return true;
				}
				if (self.hasSettingsTab) {
					try {
						self.utils.loadTemplates(self.settingsTemplatesArray, async function () {
							// Deactive btn & hide warning
							$modal.find('.widget_settings_block__fields').hide();

							const tabParams = {
								id: 'setting',
								text: 'Настройки'
							};
							const tabHtml = self.templates[self.tabItemTemplate].render({
								tab: tabParams
							});
							$modal.find('.view-integration-modal__tabs .tabs').append(tabHtml);
							const $modalBody = $modal.find('.modal-body');
							$modalBody.width($modalBody.width() + $('#setting').width() + 20);
							$modalBody.trigger('modal:centrify');
							const tabContentHtml = self.templates[self.tabContentTemplate].render({
								tab: tabParams
							});
							$modal.find('.widget-settings__desc-space').before(tabContentHtml);
							self.utils.initializeVue('.view-integration-modal__' + tabParams.id, App);
						})
					} catch (e) {
						self.utils.openAlert(error_msg, 'error');
					}
				}
			},
			onSave(fields) {
				return true
			},
			destroy() {

			},
		}
		return this
	}
})
